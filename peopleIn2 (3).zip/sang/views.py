from chartit import DataPool, Chart
from django.shortcuts import render, get_object_or_404


# Create your views here.
from sang.models import Sang


def sang2(request):
    return render(request, 'sang/sang2.html')


def sang3(request):
    return render(request, 'sang/sang3.html')


def sang4(request):
    return render(request, 'sang/sang4.html')


def sang_detail(request):

    return render(request, 'sang/sang_detail.html')


# def sang_detail(request,pk):
#     sang = get_object_or_404(Sang, pk=pk)
#
#     return render(request, 'sang/sang_detail.html')
