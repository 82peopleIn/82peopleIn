from django.apps import AppConfig


class FranchiseConfig(AppConfig):
    name = 'franchise'
