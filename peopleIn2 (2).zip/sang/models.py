from django.db import models

# class Sang(models.Model):