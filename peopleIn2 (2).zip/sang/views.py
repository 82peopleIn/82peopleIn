from chartit import DataPool, Chart
from django.shortcuts import render

# Create your views here.
def sang2(request):
    return render(request, 'sang/sang2.html')


def sang3(request):
    return render(request, 'sang/sang3.html')


def sang4(request):
    return render(request, 'sang/sang4.html')


def sang5(request):
    return render(request, 'sang/sang5.html')
