from django.apps import AppConfig


class MapConfig(AppConfig):
    name = 'map'
